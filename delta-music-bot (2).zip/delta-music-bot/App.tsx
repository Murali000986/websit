import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Team from './components/Team';
import Footer from './components/Footer';
import IntroOverlay from './components/IntroOverlay';
import Snowflakes from './components/Snowflakes';
import InviteModal from './components/InviteModal';
import { TYPING_TITLES } from './constants';

const App: React.FC = () => {
  const [isInviteOpen, setIsInviteOpen] = useState(false);

  // Title Typing Animation logic
  useEffect(() => {
    let currentTitleIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    let typingInterval: NodeJS.Timeout;

    const type = () => {
      const currentTitle = TYPING_TITLES[currentTitleIndex];
      
      if (isDeleting) {
        document.title = currentTitle.substring(0, currentCharIndex - 1);
        currentCharIndex--;
      } else {
        document.title = currentTitle.substring(0, currentCharIndex + 1);
        currentCharIndex++;
      }

      let typeSpeed = 100;

      if (!isDeleting && currentCharIndex === currentTitle.length) {
        typeSpeed = 2000; // Pause at end
        isDeleting = true;
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false;
        currentTitleIndex = (currentTitleIndex + 1) % TYPING_TITLES.length;
        typeSpeed = 500; // Pause before new word
      }

      typingInterval = setTimeout(type, typeSpeed);
    };

    type();

    return () => clearTimeout(typingInterval);
  }, []);

  const handleVideoPlay = () => {
    const video = document.querySelector('video');
    if (video) video.play().catch(() => {});
  };

  return (
    <div className="font-sans selection:bg-accent-1 selection:text-white">
      <IntroOverlay onEnter={handleVideoPlay} />
      <Snowflakes />
      <Navbar onInvite={() => setIsInviteOpen(true)} />
      
      <main>
        <Hero onInvite={() => setIsInviteOpen(true)} />
        <Features />
        <Team />
      </main>

      <Footer />
      
      <InviteModal 
        isOpen={isInviteOpen} 
        onClose={() => setIsInviteOpen(false)} 
      />
    </div>
  );
};

export default App;
