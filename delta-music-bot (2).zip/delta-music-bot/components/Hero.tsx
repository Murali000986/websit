import React from 'react';
import { Plus } from 'lucide-react';

const Hero: React.FC<{ onInvite: () => void }> = ({ onInvite }) => {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center bg-gray-900 px-4 py-12">
      
      {/* Heading */}
      <h1 className="text-white text-5xl md:text-7xl font-bold mb-6 text-center">
        A Music Disc For You
      </h1>

      {/* Paragraph */}
      <p className="text-gray-200 text-lg md:text-xl mb-10 max-w-2xl text-center">
        Delta Music Bot is a fantastic music streaming bot that operates around the clock for your server.
        It's the perfect addition for your needs, and it's created by a talented Malayali. Enjoy!
      </p>

      {/* Centered Video */}
      <div className="relative w-full max-w-4xl aspect-video rounded-3xl overflow-hidden shadow-2xl mb-10">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
        >
          {/* Using your video from public/video/Home.mp4 */}
          <source src="/video/Home.mp4?v=2" type="video/mp4" />
        </video>
        {/* Optional overlay for better contrast */}
        <div className="absolute inset-0 bg-black/30 pointer-events-none"></div>
      </div>

      {/* Invite Button */}
      <button
        onClick={() => onInvite()}
        className="flex items-center gap-3 bg-gradient-to-r from-yellow-400 to-orange-500 px-8 py-3 rounded-xl text-xl font-bold shadow-lg shadow-yellow-400/20 hover:shadow-yellow-400/40 hover:-translate-y-1 hover:scale-105 transition-all duration-300 text-white"
      >
        <span>Invite</span>
        <span className="text-white/80 font-normal text-lg">500+</span>
      </button>

    </section>
  );
};

export default Hero;
