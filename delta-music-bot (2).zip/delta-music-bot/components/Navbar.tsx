import React, { useState, useEffect } from 'react';
import { Menu, X, Plus, Gamepad2 } from 'lucide-react';
import { DISCORD_INVITE, SUPPORT_SERVER, TOP_GG } from '../constants';

const Navbar: React.FC<{ onInvite: () => void }> = ({ onInvite }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <>
      <nav 
        className={`fixed top-0 w-full z-40 transition-all duration-500 ease-out border-b border-white/10 ${
          scrolled ? 'backdrop-blur-xl bg-graphene-950/80 py-2' : 'backdrop-blur-md bg-transparent py-4'
        }`}
      >
        <div className="container mx-auto px-6 flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3 group text-decoration-none">
            <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-transparent group-hover:border-accent-1 transition-all duration-300">
               {/* Sample Logo Image: Replace with your own logo path */}
               <img src="https://images.unsplash.com/photo-1614680376593-902f74cf0d41?q=80&w=200&auto=format&fit=crop" alt="Delta Logo" className="w-full h-full object-cover" />
            </div>
            <p className="font-display text-2xl tracking-wider group-hover:text-gradient transition-all duration-300 group-hover:animate-glitch">
              DELTA
            </p>
            <div className="bg-blue-500 rounded-full p-0.5" title="Verified App">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-gray-300 hover:text-white hover:-translate-y-1 transition-transform duration-200">Home</a>
            <a href="#features" className="text-gray-300 hover:text-white hover:-translate-y-1 transition-transform duration-200">Features</a>
            <a href="#team" className="text-gray-300 hover:text-white hover:-translate-y-1 transition-transform duration-200">Team</a>
            <a href={TOP_GG} target="_blank" rel="noreferrer" className="text-gray-300 hover:text-white hover:-translate-y-1 transition-transform duration-200">Vote</a>
            <a href={SUPPORT_SERVER} target="_blank" rel="noreferrer" className="text-gray-300 hover:text-white hover:-translate-y-1 transition-transform duration-200">
               <Gamepad2 className="w-8 h-8" />
            </a>
            
            <button 
              onClick={onInvite}
              className="flex items-center gap-2 bg-gradient-to-r from-accent-1 to-accent-2 px-6 py-2 rounded-xl font-semibold shadow-[0_0_15px_rgba(255,183,0,0.3)] hover:scale-105 hover:-translate-y-1 transition-all duration-300"
            >
              <span>Invite</span>
              <Plus className="w-5 h-5" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button onClick={toggleMenu} className="md:hidden text-white z-50">
            {isOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
          </button>
        </div>
      </nav>

      {/* Mobile Overlay Nav */}
      <div className={`fixed inset-0 z-30 bg-graphene-950/95 backdrop-blur-xl flex flex-col items-center justify-center transition-all duration-500 ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
        <div className="flex flex-col items-center gap-8 text-2xl font-display">
            <a href="#home" onClick={toggleMenu} className="hover:text-accent-2 transition-colors">Home</a>
            <a href="#features" onClick={toggleMenu} className="hover:text-accent-2 transition-colors">Features</a>
            <a href="#team" onClick={toggleMenu} className="hover:text-accent-2 transition-colors">Team</a>
            <a href={TOP_GG} className="hover:text-accent-2 transition-colors">Vote</a>
            <a href={SUPPORT_SERVER} className="hover:text-accent-2 transition-colors">Discord</a>
            <button onClick={() => { onInvite(); toggleMenu(); }} className="text-accent-1">Invite Bot</button>
        </div>
      </div>
    </>
  );
};

export default Navbar;