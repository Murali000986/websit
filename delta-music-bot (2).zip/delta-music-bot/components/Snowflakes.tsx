import React from 'react';

const Snowflakes: React.FC = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {Array.from({ length: 12 }).map((_, i) => {
        const left = `${Math.floor(Math.random() * 100)}%`;
        const animationDelay = `${Math.random() * 5}s`;
        const opacity = Math.random() * 0.5 + 0.3;
        
        return (
          <div
            key={i}
            className="absolute top-[-10%] text-white text-opacity-80 animate-[spin-slow_3s_infinite]"
            style={{
              left,
              animationName: 'snowflakes-fall, snowflakes-shake',
              animationDuration: '10s, 3s',
              animationTimingFunction: 'linear, ease-in-out',
              animationIterationCount: 'infinite, infinite',
              animationDelay: `${animationDelay}, ${animationDelay}`,
              opacity
            }}
          >
            ❄
          </div>
        );
      })}
      <style>{`
        @keyframes snowflakes-fall {
          0% { top: -10%; }
          100% { top: 100%; }
        }
        @keyframes snowflakes-shake {
          0% { transform: translateX(0px); }
          50% { transform: translateX(80px); }
          100% { transform: translateX(0px); }
        }
      `}</style>
    </div>
  );
};

export default Snowflakes;