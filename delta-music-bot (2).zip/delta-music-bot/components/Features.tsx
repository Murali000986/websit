import React from 'react';
import { FEATURES } from '../constants';

const Features: React.FC = () => {
  return (
    <section id="features" className="py-32 px-4 relative">
       {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-full h-full bg-gradient-to-b from-transparent to-graphene-950 z-0 pointer-events-none"></div>
      
      <div className="container mx-auto relative z-10">
        <div className="text-center mb-20">
            <h2 className="text-accent-2 font-display text-xl mb-4">An Discord Verified Bot</h2>
            <h1 className="text-5xl font-bold">We Offer These!!</h1>
        </div>

        <div className="flex flex-wrap justify-center gap-8">
            {FEATURES.map((feature, index) => {
                const Icon = feature.icon;
                return (
                    <div 
                        key={index}
                        className="group relative w-80 h-80 bg-graphene-800 rounded-3xl p-8 flex flex-col items-center justify-center text-center transition-all duration-300 hover:bg-graphene-700 hover:-translate-y-2 hover:rotate-1 border border-white/5"
                    >
                        <div className="mb-6 p-4 bg-white/5 rounded-2xl group-hover:scale-110 transition-transform duration-300 text-accent-2">
                            <Icon size={48} />
                        </div>
                        <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                        <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                    </div>
                );
            })}
        </div>
      </div>
    </section>
  );
};

export default Features;