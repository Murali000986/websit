import React, { useState } from 'react';

interface Props {
  onEnter: () => void;
}

const IntroOverlay: React.FC<Props> = ({ onEnter }) => {
  const [visible, setVisible] = useState(true);

  const handleClick = () => {
    setVisible(false);
    setTimeout(onEnter, 500); // Allow animation to finish
  };

  if (!visible) return null;

  return (
    <div 
      className={`fixed inset-0 z-[100] bg-graphene-950 flex items-center justify-center transition-opacity duration-500 ${visible ? 'opacity-100' : 'opacity-0'}`}
      onClick={handleClick}
    >
      <div className="text-center cursor-pointer animate-pulse">
        <p className="text-2xl font-display tracking-widest text-white">CLICK TO CONTINUE</p>
      </div>
    </div>
  );
};

export default IntroOverlay;