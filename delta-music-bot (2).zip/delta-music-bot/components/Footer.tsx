import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-graphene-950 py-8 text-center border-t border-white/10">
      <div className="container mx-auto px-4">
        <p className="text-gray-500">
            Made by Sebastian Varkey &copy; {new Date().getFullYear()}
        </p>
      </div>
    </footer>
  );
};

export default Footer;