import React from 'react';
import { X, ExternalLink, ShieldCheck } from 'lucide-react';
import { DISCORD_INVITE } from '../constants';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const InviteModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleInvite = () => {
    window.location.href = DISCORD_INVITE;
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-graphene-800 rounded-2xl max-w-md w-full border border-white/10 shadow-2xl p-6 relative animate-scale-up">
        
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <X size={24} />
        </button>

        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-accent-2/20 rounded-full flex items-center justify-center text-accent-2 mb-4">
            <ShieldCheck size={32} />
          </div>
          
          <h2 className="text-2xl font-bold mb-2">Notice</h2>
          <p className="text-gray-400 mb-6">
            Join our community now to access exclusive features, updates, and perks! Don't miss out—be a part of the experience!
          </p>

          <div className="flex gap-3 w-full">
            <button 
              onClick={onClose}
              className="flex-1 py-3 rounded-xl bg-graphene-700 text-white font-medium hover:bg-graphene-600 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleInvite}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-accent-1 to-accent-2 text-white font-bold shadow-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
            >
              <span>Invite Now</span>
              <ExternalLink size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InviteModal;