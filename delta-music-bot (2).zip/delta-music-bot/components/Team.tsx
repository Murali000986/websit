import React from 'react';
import { DEVELOPERS } from '../constants';

const Team: React.FC = () => {
  // Separate Owner and Devs for layout purposes based on original design
  const owner = DEVELOPERS.find(d => d.roleColor === 'owner');
  const devs = DEVELOPERS.filter(d => d.roleColor === 'dev');

  return (
    <section id="team" className="py-20 px-4 bg-graphene-900/50">
      <div className="container mx-auto max-w-4xl">
        
        {/* Creator */}
        <div className="mb-20">
            <div className="text-center mb-10">
                <h2 className="text-xl font-bold text-gray-400">Bot Creator</h2>
                <h1 className="text-4xl font-bold">Who Made Delta?</h1>
            </div>
            {owner && <TeamCard member={owner} reverse={false} />}
        </div>

        {/* Developers */}
        <div>
            <div className="text-center mb-10">
                <h2 className="text-xl font-bold text-gray-400">Bot Developers</h2>
                <h1 className="text-4xl font-bold">Who Are Developers?</h1>
            </div>
            <div className="flex flex-col gap-8">
                {devs.map((dev, i) => (
                    <TeamCard key={i} member={dev} reverse={i % 2 !== 0} />
                ))}
            </div>
        </div>

      </div>
    </section>
  );
};

const TeamCard: React.FC<{ member: typeof DEVELOPERS[0], reverse?: boolean }> = ({ member, reverse }) => {
    return (
        <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center bg-graphene-800 rounded-3xl p-6 md:p-10 gap-8 hover:-translate-y-2 transition-transform duration-300 border border-white/5 shadow-xl`}>
            <div className="w-64 h-64 shrink-0 rounded-2xl overflow-hidden border-4 border-graphene-700">
                <img src={member.avatar} alt={member.name} className="w-full h-full object-cover" />
            </div>
            <div className="text-center md:text-left flex flex-col items-center md:items-start">
                <span className={`text-2xl font-bold mb-2 ${member.roleColor === 'owner' ? 'text-blue-400' : 'text-red-500'}`}>
                    {member.role}
                </span>
                <a 
                    href={member.profileUrl} 
                    className="text-3xl font-bold text-white hover:text-gradient transition-all duration-300"
                >
                    {member.name}
                </a>
            </div>
        </div>
    );
};

export default Team;