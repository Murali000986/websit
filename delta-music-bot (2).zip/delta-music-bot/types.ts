import { LucideIcon } from 'lucide-react';

export interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
}

export interface Developer {
  name: string;
  role: string;
  avatar: string;
  roleColor: 'admin' | 'owner' | 'dev';
  profileUrl: string;
}

export interface NavItem {
  label: string;
  href: string;
  isButton?: boolean;
  icon?: boolean;
}