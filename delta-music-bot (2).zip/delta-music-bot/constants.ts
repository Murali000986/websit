import { Eye, Headphones, Zap, Link as LinkIcon } from 'lucide-react';
import { Feature, Developer } from './types';

export const DISCORD_INVITE = "https://discord.com/oauth2/authorize?client_id=1284517036260855901&permissions=66448640&integration_type=0&scope=bot+applications.commands";
export const SUPPORT_SERVER = "https://discord.gg/udsFR6sTyy";
export const TOP_GG = "https://top.gg/bot/1284517036260855901";

export const FEATURES: Feature[] = [
  {
    icon: Eye,
    title: "Reliable",
    description: "Never miss a beat with Delta's 24/7 Uptime."
  },
  {
    icon: Headphones,
    title: "High Quality Audio",
    description: "Stream your audio at the best quality possible!"
  },
  {
    icon: Zap,
    title: "Mix and Match",
    description: "Don't just listen, take control. Shape your own ultimate playlists right inside Delta."
  },
  {
    icon: LinkIcon,
    title: "Search on the go!",
    description: "Simply type the name of your song and let Delta find it for you."
  }
];

export const DEVELOPERS: Developer[] = [
  {
    name: "igl_akshay",
    role: "! DELTA",
    roleColor: "owner",
    // Replace with actual team member photo
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=300&auto=format&fit=crop",
    profileUrl: "#"
  },
  {
    name: "beunko__1",
    role: "Hikaruuu</>",
    roleColor: "dev",
    // Replace with actual team member photo
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=300&auto=format&fit=crop",
    profileUrl: "#"
  },
  {
    name: "sanju.dev",
    role: "S 4 N J U</>",
    roleColor: "dev",
    // Replace with actual team member photo
    avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?q=80&w=300&auto=format&fit=crop",
    profileUrl: "#"
  }
];

export const TYPING_TITLES = [
  "Delta Music",
  "4K Music",
  "Listen to the music",
  "Spotify Streams",
  "DJ Support",
  "Make A Room Of Music"
];